﻿public class CleansingCenter : Centre
{
    public CleansingCenter(string name)
        : base(name) { }
}
