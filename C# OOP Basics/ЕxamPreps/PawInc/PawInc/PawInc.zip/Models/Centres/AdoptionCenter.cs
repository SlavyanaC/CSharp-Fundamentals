﻿public class AdoptionCenter : Centre
{
    public AdoptionCenter(string name)
        : base(name) { }
}
