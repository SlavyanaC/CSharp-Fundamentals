﻿public class CastrationCenter : Centre
{
    public CastrationCenter(string name)
        : base(name) { }
}
