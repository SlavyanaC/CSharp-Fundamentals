﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class ErrorMessages
{
    public static string InvalidCentreType => "Invalid centre type";

    public static string InvalidAnimalType => "Invalid animal type";
}
